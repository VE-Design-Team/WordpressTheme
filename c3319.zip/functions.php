<?php
/**
 * Understrap functions and definitions
 *
 * @package understrap
 */

/**
 * Theme setup and custom theme supports.
 */
require get_template_directory() . '/inc/setup.php';

/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
require get_template_directory() . '/inc/widgets.php';

/**
 * Load functions to secure your WP install.
 */
require get_template_directory() . '/inc/security.php';

/**
 * Enqueue scripts and styles.
 */
require get_template_directory() . '/inc/enqueue.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/pagination.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';





/**
 * Load custom WordPress nav walker.
 */
require get_template_directory() . '/inc/bootstrap-wp-navwalker.php';



/**
 * Load Editor functions.
 */
require get_template_directory() . '/inc/editor.php';
/**
 *  Load Advanced Custom Fields
 */
 // 1. customize ACF path
 add_filter('acf/settings/path', 'my_acf_settings_path');

 function my_acf_settings_path( $path ) {

     // update path
     $path = get_stylesheet_directory() . '/acf/';

     // return
     return $path;

 }


 // 2. customize ACF dir
 add_filter('acf/settings/dir', 'my_acf_settings_dir');

 function my_acf_settings_dir( $dir ) {

     // update path
     $dir = get_stylesheet_directory_uri() . '/acf/';

     // return
     return $dir;

 }


 // 3. Hide ACF field group menu item
 //add_filter('acf/settings/show_admin', '__return_false');


 // 4. Include ACF
 include_once( get_stylesheet_directory() . '/acf/acf.php' );

 /**
  * Load iFrame helper content
  */
 require get_template_directory() . '/inc/iframe.php';
// Glossary post type
// Register Custom Post Type
// Register Custom Post Type
function glossary() {

	$labels = array(
		'name'                  => _x( 'Glossary', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Glossary', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Glossary', 'text_domain' ),
		'name_admin_bar'        => __( 'Glossary', 'text_domain' ),
		'archives'              => __( 'Glossary Archives', 'text_domain' ),
		'attributes'            => __( 'Glossary Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Parent Glossary:', 'text_domain' ),
		'all_items'             => __( 'All Glossaries', 'text_domain' ),
		'add_new_item'          => __( 'Add New Glossaries', 'text_domain' ),
		'add_new'               => __( 'Add New', 'text_domain' ),
		'new_item'              => __( 'New Item', 'text_domain' ),
		'edit_item'             => __( 'Edit Item', 'text_domain' ),
		'update_item'           => __( 'Update Item', 'text_domain' ),
		'view_item'             => __( 'View Item', 'text_domain' ),
		'view_items'            => __( 'View Items', 'text_domain' ),
		'search_items'          => __( 'Search Item', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
		'items_list'            => __( 'Items list', 'text_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
	);
	$args = array(
		'label'                 => __( 'Glossary', 'text_domain' ),
		'description'           => __( 'Builds a glossary for external access', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'custom-fields' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-list-view',
		'show_in_admin_bar'     => false,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => false,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'rewrite'               => false,
		'capability_type'       => 'page',
	);
	register_post_type( 'glossary', $args );

}
add_action( 'init', 'glossary', 0 );
